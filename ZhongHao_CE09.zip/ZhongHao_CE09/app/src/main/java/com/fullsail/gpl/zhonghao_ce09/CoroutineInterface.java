// Hao Zhong
// GPL - 202110
// CoroutineInterface.java
package com.fullsail.gpl.zhonghao_ce09;

public interface CoroutineInterface {
    void onPre();
    void onFinish(String data);
}
